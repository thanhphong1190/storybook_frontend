export { default as SVGIcon, IconEnums } from './svgIcon'
