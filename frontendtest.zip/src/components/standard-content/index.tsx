export { StandardContent, PageContentProps } from './StandardContent'
