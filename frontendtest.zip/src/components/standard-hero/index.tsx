export { StandardHero, StandardHeroProps } from './StandardHero'
