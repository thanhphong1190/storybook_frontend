export { default as WhatsHot, WhatsHotProps } from './WhatsHot'
