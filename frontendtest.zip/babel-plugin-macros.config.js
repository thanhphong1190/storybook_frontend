module.exports = {
  tailwind: {
    plugins: ['macros'],
    config: './tailwind.config.js',
    format: 'auto',
  },
}
